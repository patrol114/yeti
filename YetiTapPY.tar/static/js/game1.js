const gameUrl = window.location.origin;
const gamePage = document.getElementById('gamePage');

const elements = {
    tabs: document.querySelectorAll('.tab'),
    tabContents: document.querySelectorAll('.tab-content'),
    coin: document.getElementById('coin'),
    coinCount: document.getElementById('coinCountElement'),
    energiaFill: document.getElementById('energiaFill'),
    levelFill: document.getElementById('levelFill'),
    levelDisplay: document.getElementById('levelElement'),
    energiaText: document.getElementById('energiaText'),
    levelText: document.getElementById('levelText'),
    rechargeButton: document.getElementById('rechargeButton'),
    lotteryButton: document.getElementById('lotteryButton'),
    gameContainer: document.querySelector('.game-frame'),
};

let session_id = sessionStorage.getItem('session_id');
let token = sessionStorage.getItem('token');
let userProgress = JSON.parse(sessionStorage.getItem('userProgress')) || {
    energia: 0,
    maxenergia: 1000,
    level: 1,
    experience: 0,
    coins: 0
};

// Logowanie z timestampem
function logWithTimestamp(message, level = 'log') {
    const timestamp = new Date().toISOString();
    console[level](`[${timestamp}] ${message}`);
}

// Śledzenie wydajności
function trackPerformance(functionName, startTime) {
    const duration = performance.now() - startTime;
    logWithTimestamp(`${functionName} executed in ${duration.toFixed(2)}ms`, 'debug');
}
// Funkcja do logowania z timestampem
function logWithTimestamp(message, level = 'log') {
    const timestamp = new Date().toISOString();
    console[level](`[${timestamp}] ${message}`);
}

// Funkcje autoryzacji i sesji
async function validateToken(token) {
    try {
        console.log("Token do walidacji:", token); // Logowanie tokena
        const decoded = jwt_decode(token); // Zakładam, że używasz jwt-decode
        console.log("Zdekodowany token:", decoded); // Logowanie zdekodowanego tokena
        return decoded;
    } catch (error) {
        logWithTimestamp(`Error in validateToken: ${error.message}`, 'error');
        return null;
    }
}

async function validateSession(session_id, token) {
    try {
        console.log("Walidacja sesji:", session_id, token); // Logowanie sesji i tokenu
        const response = await secureFetch(`${gameUrl}/api/session/validate`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'X-Session-ID': session_id
            }
        });
        const data = await response.json();
        console.log("Dane walidacji sesji:", data); // Logowanie danych walidacji
        return data.valid;
    } catch (error) {
        logWithTimestamp(`Error in validateSession: ${error.message}`, 'error');
        return false;
    }
}

// Funkcja do pobierania wartości z localStorage
function getStorageItem(key) {
    return localStorage.getItem(key);
}

// Funkcja do zapisywania wartości w localStorage
function setStorageItem(key, value) {
    localStorage.setItem(key, value);
}

// Funkcja do usuwania wartości z localStorage
function removeStorageItem(key) {
    localStorage.removeItem(key);
}

// Funkcja do pobierania session_id i tokena
async function getSessionIdAndToken() {
    console.log("Pobieranie ID sesji i tokenu"); // Dodatkowe logowanie
    sessionId = getStorageItem('session_id');
    token = getStorageItem('token');

    console.log("ID sesji:", sessionId); // Logowanie ID sesji
    console.log("Token:", token); // Logowanie tokenu

    if (!sessionId || !token) {
        console.log("ID sesji lub token nie znaleziono w localStorage, sprawdzanie URL"); // Logowanie
        const urlParams = new URLSearchParams(window.location.search);
        sessionId = urlParams.get('session_id');
        token = urlParams.get('token');

        if (sessionId && token) {
            console.log("Znaleziono ID sesji i token w URL", sessionId, token); // Logowanie
            setStorageItem('session_id', sessionId);
            setStorageItem('token', token);
        } else {
            logWithTimestamp('Session ID or token not found in URL or storage', 'warn');
            return false;
        }
    }

    try {
        console.log("Walidacja tokenu i sesji"); // Logowanie
        if (!await validateToken(token) || !await validateSession(sessionId, token)) {
            throw new Error('Invalid token or session');
        }
        console.log("Token i sesja poprawne"); // Logowanie
        return true;
    } catch (error) {
        logWithTimestamp(`Error in getSessionIdAndToken: ${error.message}`, 'error');
        removeStorageItem('session_id');
        removeStorageItem('token');
        return false;
    }
}

// Inicjalizacja Telegram Web App
Telegram.WebApp.onEvent('theme_changed', (event) => {
    logWithTimestamp(`Theme changed: ${JSON.stringify(event.theme_params)}`);
});

Telegram.WebApp.onEvent('viewport_changed', (event) => {
    logWithTimestamp(`Viewport changed: ${JSON.stringify(event)}`);
});

// Ustawianie kolorów nagłówka i tła za pomocą theme_params
Telegram.WebApp.onEvent('themeChanged', () => {
    const themeParams = tg.themeParams;
    if (themeParams) {
        Telegram.WebApp.setHeaderColor({ color: themeParams['bg_color'] });
        Telegram.WebApp.setBackgroundColor({ color: themeParams['bg_color'] });
    }
});

Telegram.WebApp.expand();
// Usunięto setupMainButton, ponieważ nie jest dostępna w starszych wersjach SDK
// Telegram.WebApp.setupMainButton({ is_visible: false }); 

// Inicjalizacja gry
logWithTimestamp('Gra została zainicjalizowana pomyślnie');

// Automatyczne odświeżanie tokenu
function startTokenRefreshInterval() {
    setInterval(async () => {
        const sessionIsValid = await getSessionIdAndToken();
        if (!sessionIsValid) {
            logWithTimestamp('Invalid session detected during token refresh', 'warn');
            // Dodatkowe logiki przy nieważnej sesji
        } else {
            logWithTimestamp('Token refreshed successfully', 'log');
        }
    }, 600000); // co 10 minut
}

startTokenRefreshInterval();


function secureFetch(url, options) {
    const token = getToken(); // funkcja pobierająca token
    if (!token) {
        console.error('Missing token');
        return;
    }

    options.headers = {
        ...options.headers,
        'Authorization': `Bearer ${token}`
    };

    return fetch(url, options)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .catch(error => {
            console.error('Fetch error:', error);
        });
}

        elements.modalClose.onclick = function() {
            elements.modal.style.display = 'none';
        }

        elements.coin.addEventListener('click', async function(event) {
            if (userProgress.energy > 0) {
                try {
                    const response = await fetch("/api/game/click", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify({})
                    });

                    if (response.ok) {
                        const data = await response.json();
                        updateUserProgress(data);
                        updateUI();

                        elements.coin.style.transform = 'scale(1.2)';
                        setTimeout(() => {
                            elements.coin.style.transform = 'scale(1)';
                        }, 100);

                        const snowballEffect = document.createElement('div');
                        snowballEffect.classList.add('snowballEffect');
                        snowballEffect.textContent = `+1`;
                        const rect = elements.gameContainer.getBoundingClientRect();
                        const x = event.clientX - rect.left;
                        const y = event.clientY - rect.top;

                        snowballEffect.style.left = `${x - 20}px`;
                        snowballEffect.style.top = `${y - 20}px`;
                        elements.gameContainer.appendChild(snowballEffect);
                        setTimeout(() => {
                            elements.gameContainer.removeChild(snowballEffect);
                        }, 600);

                        if (data.levelUp) {
                            showModal('Gratulacje!', `Osiągnąłeś poziom ${data.level}`);
                        }
                    } else {
                        if (response.status === 401) {
                            throw new Error('Unauthorized');
                        } else {
                            const error = await response.json();
                            console.error('Failed to update game state:', error.error);
                            showModal('Błąd', error.error);
                        }
                    }
                } catch (error) {
                    console.error('Error handling coin click:', error);
                    showModal('Błąd', 'Wystąpił nieoczekiwany błąd. Spróbuj ponownie później.');
                }
            } else {
                showModal('Brak energii', 'Nie masz wystarczającej energii. Poczekaj, aż się naładuje.');
            }
        });

async function loadUserData() {
    try {
        await getSessionIdAndToken();

        const response = await secureFetch(`${gameUrl}/api/user/stats`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                session_id: session_id,
                token: token,
            })
        });

        if (response && response.ok) {
            const data = await response.json();
            updateUserProgress(data);
            updateUI();
        } else {
            throw new Error('Błąd podczas ładowania danych użytkownika');
        }
    } catch (error) {
        console.error('Błąd podczas ładowania danych użytkownika:', error);
        showNotification('Nie udało się załadować danych użytkownika', 'error');
    }
}


// Pobieranie i walidacja sesji i tokena
// Funkcje pomocnicze do obsługi różnych metod przechowywania
function setStorageItem(key, value) {
    try {
        localStorage.setItem(key, value);
        sessionStorage.setItem(key, value);
        document.cookie = `${key}=${value}; path=/; SameSite=Strict; Secure`;
    } catch (e) {
        console.error('Error setting storage item:', e);
    }
}

function getStorageItem(key) {
    let value = sessionStorage.getItem(key) || localStorage.getItem(key);
    if (!value) {
        const cookie = document.cookie.split('; ').find(row => row.startsWith(`${key}=`));
        value = cookie ? cookie.split('=') : null;
    }
    return value;
}

function removeStorageItem(key) {
    try {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
        document.cookie = `${key}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; SameSite=Strict; Secure`;
    } catch (e) {
        console.error('Error removing storage item:', e);
    }
}

async function handleAuthError() {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('session_id');
    showModal('Błąd sesji', 'Twoja sesja wygasła lub jest nieprawidłowa. Proszę zalogować się ponownie.');
    // await redirectToLoginPage();
}

async function refreshToken() {
    const session_id = sessionStorage.getItem('session_id');
    const token = sessionStorage.getItem('token');

    if (!session_id || !token) {
        logWithTimestamp('Missing session_id or token for refresh', 'warn');
        return false;
    }

    try {
        const response = await fetch('/api/refresh-token', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'X-Session-ID': session_id,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ session_id })
        });

        if (response.ok) {
            const data = await response.json();
            sessionStorage.setItem('token', data.token);
            if (data.session_id) {
                sessionStorage.setItem('session_id', data.session_id);
            }
            return true;
        } else {
            logWithTimestamp('Token refresh failed', 'warn');
            return false;
        }
    } catch (error) {
        logWithTimestamp(`Error in refreshToken: ${error.message}`, 'error');
        return false;
    }
}

// Event listener do ładowania danych użytkownika
window.addEventListener('load', async () => {
    const sessionValid = await getSessionIdAndToken();
    if (sessionValid) {
        await loadUserData();
        startTokenRefreshInterval();
    } else {
        await redirectToLoginPage();
    }
});

// Interval odświeżania tokena
function startTokenRefreshInterval() {
    setInterval(() => {
        if (new Date() > new Date(sessionStorage.getItem('expirationTime'))) {
            refreshToken();
        }
    }, 6000);
    console.debug('startTokenRefreshInterval executed successfully');
}

// Zainicjalizowanie odświeżania tokena
startTokenRefreshInterval();

// Event listeners
window.addEventListener('load', () => {
    loadUserData();
    startTokenRefreshInterval(); 
});

// Aktualizacja UI
function updateUI() {
    const { energia, maxenergia, level, experience, coins } = userProgress;

    elements.energiaFill.style.width = `${(energia / maxenergia) * 100}%`;
    elements.energiaText.textContent = `${energia} / ${maxenergia}`;
    elements.levelFill.style.width = `${(experience / 100) * 100}%`;
    elements.levelText.textContent = `Poziom ${level}`;
    elements.coinCount.textContent = coins;

    logWithTimestamp('updateUI executed successfully');
}

// Przekierowanie na stronę logowania
function redirectToLoginPage() {
    window.location.href = '/rotected-route';
}

// Funkcja do walidacji danych wejściowych
function sanitizeInput(input) {
    return input.replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Modyfikacja funkcji showNotification
function showNotification(title, message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `<strong>${sanitizeInput(title)}</strong><p>${sanitizeInput(message)}</p>`;
    document.body.appendChild(notification);

    setTimeout(() => {
        document.body.removeChild(notification);
    }, 3000);
}

// Modyfikacja funkcji showModal
function showModal(title, message) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h2>${sanitizeInput(title)}</h2>
            <p>${sanitizeInput(message)}</p>
        </div>
    `;

    document.body.appendChild(modal);
    const closeButton = modal.querySelector('.close-button');

    closeButton.addEventListener('click', () => {
        document.body.removeChild(modal);
    });

    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

// Aktualizacja danych użytkownika
function updateUserProgress(data) {
    userProgress.energia = data.energia;
    userProgress.maxenergia = data.maxenergia;
    userProgress.level = data.level;
    userProgress.experience = data.experience;
    userProgress.coins = data.coins;

    sessionStorage.setItem('userProgress', JSON.stringify(userProgress));
    logWithTimestamp('updateUserProgress executed successfully');
}

// Obsługa kliknięcia przycisku recharge
elements.rechargeButton.addEventListener('click', async () => {
    try {
        await getSessionIdAndToken();

        const response = await secureFetch(`${gameUrl}/api/game/recharge`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': session_id,
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
                session_id: session_id,
                token: token
            })
        });

        if (!response.ok) {
            throw new Error('Błąd podczas ładowania energii');
        }

        const data = await response.json();
        updateUserProgress(data);
        updateUI();
        showNotification('Energie zreładowana!', 'Twoja energia została zreładowana pomyślnie.', 'success');
    } catch (error) {
        console.error('Błąd podczas ładowania energii:', error);
        showNotification('Nie udało się naładować energii', 'error');
    }
});

// Obsługa kliknięcia przycisku lottery
elements.lotteryButton.addEventListener('click', async () => {
    try {
        await getSessionIdAndToken();

        const response = await secureFetch(`${gameUrl}/api/game/lottery`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': session_id,
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
                session_id: session_id,
                token: token
            })
        });

        if (!response.ok) {
            throw new Error('Błąd podczas losowania');
        }

        const data = await response.json();
        updateUserProgress(data);
        updateUI();
        showNotification('Losowanie zakończone!', 'Otrzymałeś nagrodę z losowania.', 'success');
    } catch (error) {
        console.error('Błąd podczas losowania:', error);
        showNotification('Nie udało się zakończyć losowania', 'error');
    }
});