const gameUrl = window.location.origin;
const gamePage = document.getElementById('gamePage');

const elements = {
    tabs: document.querySelectorAll('.tab'),
    tabContents: document.querySelectorAll('.tab-content'),
    coin: document.getElementById('coin'),
    coinCount: document.getElementById('coinCountElement'),
    energiaFill: document.getElementById('energiaFill'),
    levelFill: document.getElementById('levelFill'),
    levelDisplay: document.getElementById('levelElement'),
    energiaText: document.getElementById('energiaText'),
    levelText: document.getElementById('levelText'),
    rechargeButton: document.getElementById('rechargeButton'),
    lotteryButton: document.getElementById('lotteryButton'),
    gameContainer: document.querySelector('.game-frame'),
};

let session_id = sessionStorage.getItem('session_id');
let token = sessionStorage.getItem('token');
let csrfToken = sessionStorage.getItem('csrf_token'); // CSRF token
let userProgress = JSON.parse(sessionStorage.getItem('userProgress')) || {
  energia: 0,
  maxenergia: 1000,
  level: 1,
  experience: 0,
  coins: 0
};
async function getSessionIdAndToken() {
    const urlParams = new URLSearchParams(window.location.search);
    session_id = urlParams.get('session_id');
    token = urlParams.get('token');
    csrfToken = urlParams.get('csrf_token'); // Get CSRF token from URL

    if (session_id && token && csrfToken) {
        sessionStorage.setItem('session_id', session_id);
        sessionStorage.setItem('token', token);
        sessionStorage.setItem('csrf_token', csrfToken);
        console.log('Session ID, token, and CSRF token saved:', session_id, token, csrfToken);
    } else {
        console.error('Nie można uzyskać session_id, tokena lub CSRF tokena z URL');
        redirectToLoginPage();
    }
    console.debug('getSessionIdAndToken wykonane poprawnie');
}

async function loadUserData() {
    try {
        if (!session_id || !token) {
            await getSessionIdAndToken(); 
        }

        const response = await secureFetch(`${gameUrl}/game`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken // Include CSRF token in headers
            },
            body: JSON.stringify({
                session_id: session_id,
                token: token,
            })
        });

        if (!response.ok) {
            throw new Error('Błąd podczas ładowania danych użytkownika');
        }

        const data = await response.json();
        updateUserProgress(data);
        updateUI();
    } catch (error) {
        console.error('Błąd podczas ładowania danych użytkownika:', error);
        showNotification('Nie udało się załadować danych użytkownika', 'error');
    }
}

async function secureFetch(url, options = {}) {
    const token = sessionStorage.getItem('token');
    const session_id = sessionStorage.getItem('session_id');
    const csrfToken = sessionStorage.getItem('csrf_token'); // Retrieve CSRF token

    if (!token || !session_id || !csrfToken) {
        console.error('Missing token, session_id, or CSRF token.');
        handleAuthError();
        return;
    }

    const headers = {
        ...options.headers,
        'Authorization': `Bearer ${token}`,
        'Session-ID': session_id,
        'X-CSRF-Token': csrfToken, // Include CSRF token in headers
        'Content-Type': 'application/json' 
    };

  try {
    // Wymuszenie metody POST dla wszystkich żądań secureFetch
    const response = await fetch(url, { ...options, method: 'POST', headers }); 

    // ... (reszta kodu secureFetch) ...

  } catch (error) {
    // ... (obsługa błędu secureFetch) ...
  }
}
async function getSessionId() {
  const response = await fetch(`${gameUrl}/api/start`);
  const data = await response.json();
  return data.session_id;
}

async function getToken(session_id) {
  const response = await fetch(`${gameUrl}/game?session_id=${session_id}`);
  const data = await response.json();
  return data.token;
}


updateUI() {
    elements.coinCount.textContent = userProgress.coins;
    elements.energiaFill.style.width = `${(userProgress.energia / userProgress.maxenergia) * 100}%`;
    elements.levelFill.style.width = `${(userProgress.experience / (userProgress.level * 1000)) * 100}%`;
    elements.levelDisplay.textContent = userProgress.level;
    elements.energiaText.textContent = `${userProgress.energia}/${userProgress.maxenergia}`;
    elements.levelText.textContent = `${userProgress.experience}/${userProgress.level * 1000}`;
    console.debug('updateUI wykonane poprawnie');
  }

  async function initApp() {
    await getSessionIdAndToken();
    console.log('Session ID:', sessionStorage.getItem('session_id'));
    console.log('Token:', sessionStorage.getItem('token'));
    await loadUserData();
    applyTheme(tg.themeParams);
    console.debug('initApp wykonane poprawnie');
    startTokenRefreshInterval();
    startAutoSave();
  }

  function updateUI() {
    elements.coinCount.textContent = userProgress.coins;
    elements.energiaFill.style.width = `${(userProgress.energia / userProgress.maxenergia) * 100}%`;
    elements.levelFill.style.width = `${(userProgress.experience / (userProgress.level * 1000)) * 100}%`;
    elements.levelDisplay.textContent = userProgress.level;
    elements.energiaText.textContent = `${userProgress.energia}/${userProgress.maxenergia}`;
    elements.levelText.textContent = `${userProgress.experience}/${userProgress.level * 1000}`;
    console.debug('updateUI wykonane poprawnie');
  }

  function applyTheme(theme) {
    document.documentElement.style.setProperty('--bg-color', theme.bg_color);
    document.documentElement.style.setProperty('--text-color', theme.text_color);
    document.documentElement.style.setProperty('--hint-color', theme.hint_color);
    document.documentElement.style.setProperty('--link-color', theme.link_color);
    document.documentElement.style.setProperty('--button-color', theme.button_color);
    document.documentElement.style.setProperty('--button-text-color', theme.button_text_color);

    tg.MainButton.setParams({
      color: theme.button_color,
      text_color: theme.button_text_color
    });
    tg.setBackgroundColor(theme.bg_color);
    console.debug('applyTheme wykonane poprawnie');
  }

async function initApp() {
  await getSessionIdAndToken();
  console.log('Session ID:', sessionStorage.getItem('session_id'));
  console.log('Token:', sessionStorage.getItem('token'));
  await loadUserData();
  applyTheme(tg.themeParams);
  console.debug('initApp wykonane poprawnie');
  startTokenRefreshInterval();
  startAutoSave();
}

async function secureFetch(url, options = {}) {
  const session_id = sessionStorage.getItem('session_id');
  const token = sessionStorage.getItem('token');

  if (!session_id || !token) {
    console.error('Missing token or session_id.');
    handleAuthError();
    return;
  }

  const headers = {
    ...options.headers,
    'Authorization': `Bearer ${token}`,
    'Session-ID': session_id,
    'Content-Type': 'application/json'
  };

  try {
    const response = await fetch(url, { ...options, method: 'POST', headers });

    if (!response.ok) {
      if (response.status === 401) {
        console.error('Unauthorized: Invalid token');
        handleAuthError();
      } else {
        console.error('Request error:', response.status, await response.text());
        showNotification('Wystąpił błąd podczas komunikacji z serwerem', 'error');
      }
      return null;
    }

    console.debug('secureFetch wykonane poprawnie');
    return response;
  } catch (error) {
    console.error('Network error:', error);
    showNotification('Wystąpił błąd sieci', 'error');
    return null;
  }
}

async function refreshToken() {
  try {
    const response = await fetch(`${gameUrl}/api/refresh-token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        session_id: sessionStorage.getItem('session_id'),
        token: sessionStorage.getItem('token'),
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to refresh token');
    }

    const data = await response.json();
    sessionStorage.setItem('token', data.token);
    sessionStorage.setItem('expirationTime', data.expiration_time);
    console.debug('refreshToken wykonane poprawnie');
  } catch (error) {
    console.error('Error refreshing token:', error);
    handleAuthError();
  }
}

  function startTokenRefreshInterval() {
    setInterval(() => {
      if (new Date() > new Date(sessionData.expirationTime)) {
        refreshToken();
      }
    }, 6000);
    console.debug('startTokenRefreshInterval wykonane poprawnie');
  }

  function updateUserProgress(data) {
    userProgress = {
      energia: data.energia,
      maxenergia: data.max_energia || 1000,
      level: data.level,
      experience: data.experience,
      coins: data.coins
    };
    console.debug('updateUserProgress wykonane poprawnie');
  }

  function updateUIWithUserData() {
    elements.levelDisplay.innerText = userProgress.level;
    elements.coinCount.innerText = userProgress.coins;
    elements.energiaFill.style.width = `${(userProgress.energia / userProgress.maxenergia) * 100}%`;
    elements.energiaText.innerText = `${userProgress.energia} / ${userProgress.maxenergia}`;
    const expForNextLevel = 100 * Math.pow(1.5, userProgress.level - 1);
    elements.levelFill.style.width = `${(userProgress.experience / expForNextLevel) * 100}%`;
    elements.levelText.innerText = `${userProgress.experience} / ${expForNextLevel}`;
    console.debug('updateUIWithUserData wykonane poprawnie');
  }

  // Obsługa kliknięcia w YetiCoin
  elements.coin.addEventListener('click', async (event) => {
    if (energy > 0) {
      if (!sessionId || !token) {
        showModal('Błąd', 'Sesja gry nie została zainicjalizowana. Proszę zrestartować grę.');
        return;
      }

      try {
        const response = await fetch(`${gameUrl}/game/click`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            'X-Session-ID': sessionId,
          },
        });

        if (response.ok) {
          const data = await response.json();
          updateUIWithUserData(data);

          elements.coin.style.transform = 'scale(1.2)';
          setTimeout(() => {
            elements.coin.style.transform = 'scale(1)';
          }, 100);

          const snowballEffect = document.createElement('div');
          snowballEffect.classList.add('snowballEffect');
          snowballEffect.textContent = `+1`;
          const rect = elements.gameContainer.getBoundingClientRect();
          const x = event.clientX - rect.left;
          const y = event.clientY - rect.top;

          snowballEffect.style.left = `${x - 20}px`;
          snowballEffect.style.top = `${y - 20}px`;
          elements.gameContainer.appendChild(snowballEffect);
          setTimeout(() => {
            elements.gameContainer.removeChild(snowballEffect);
          }, 600);

          if (data.level > level) {
            showModal('Gratulacje!', `Osiągnąłeś poziom ${data.level}`);
          }
        } else {
          if (response.status === 401) {
            console.error('Nieprawidłowy token JWT');
          } else {
            console.error('Failed to update game state');
          }
        }
      } catch (error) {
        console.error('Błąd podczas aktualizacji stanu gry:', error);
      }
    } else {
      showModal('Brak energii', 'Nie masz wystarczającej energii. Poczekaj, aż się naładuje.');
    }
  });
  function rechargeenergia() {
    const lastRecharge = sessionStorage.getItem('lastRecharge');
    const now = Date.now();
    if (!lastRecharge || (now - lastRecharge) > 43200000) {
      if (userProgress.energia < userProgress.maxenergia) {
        userProgress.energia += 100;
        if (userProgress.energia > userProgress.maxenergia) {
          userProgress.energia = userProgress.maxenergia;
        }
        updateUIWithUserData();
        sessionStorage.setItem('lastRecharge', now);
        window.open('https://owhaptih.net/4/7598732', '_blank');
        showNotification('Energia została naładowana!', 'success');
      } else {
        showNotification('Masz już maksymalną ilość energii.', 'info');
      }
    } else {
      showNotification('Możesz ładować energię tylko raz na 12 godzin.', 'warning');
    }
    console.debug('rechargeenergia wykonane poprawnie');
  }

  function startEnergiaInterval() {
    energiaInterval = setInterval(() => {
      if (userProgress.energia < userProgress.maxenergia) {
        userProgress.energia += 1;
        updateUIWithUserData();
      }
    }, 10000);
    console.debug('startEnergiaInterval wykonane poprawnie');
  }

  function checkenergia(requiredenergia) {
    if (userProgress.energia < requiredenergia) {
      showNotification(`Niewystarczająca ilość energii. Potrzebujesz ${requiredenergia} energii.`, 'warning');
      return false;
    }
    console.debug('checkenergia wykonane poprawnie');
    return true;
  }

  function updateBuildingsUI(buildings) {
    const buildingsContainer = document.getElementById('buildingsContainer');
    buildingsContainer.innerHTML = '';

    buildings.forEach(building => {
      const buildingElement = document.createElement('div');
      buildingElement.classList.add('building');
      buildingElement.innerHTML = `
        <h3>${building.name}</h3>
        <p>Poziom: ${building.level}</p>
        <p>Produkcja: ${building.production}</p>
      `;
      buildingsContainer.appendChild(buildingElement);
    });
    console.debug('updateBuildingsUI wykonane poprawnie');
  }

  function updateBoostsUI(boosts) {
    const boostsContainer = document.getElementById('boostsContainer');
    boostsContainer.innerHTML = '';

    boosts.forEach(boost => {
      const boostElement = document.createElement('div');
      boostElement.classList.add('boost');
      boostElement.innerHTML = `
        <h3>${boost.name}</h3>
        <p>Czas trwania: ${boost.duration}</p>
        <p>Wzrost: ${boost.increase}</p>
      `;
      boostsContainer.appendChild(boostElement);
    });
    console.debug('updateBoostsUI wykonane poprawnie');
  }

  function handleAuthError() {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('session_id');
    showModal('Błąd autoryzacji', 'Twoja sesja wygasła. Zaloguj się ponownie.');
    console.debug('handleAuthError wykonane poprawnie');
  }

  function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    console.debug('getCsrfToken wykonane poprawnie');
    return meta ? meta.getAttribute('content') : '';
  }

  async function playLottery() {
    if (!checkenergia(50)) return;

    try {
      const response = await secureFetch(`${gameUrl}/api/lottery/play`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Błąd podczas grania w loterię');

      const result = await response.json();
      userProgress.energia -= 50;
      userProgress.coins += result.prize;
      updateUIWithUserData();
      showNotification(`Wygrałeś ${result.prize} monet!`, 'success');
      console.debug('playLottery wykonane poprawnie');
    } catch (error) {
      console.error('Błąd loterii:', error);
      showNotification('Wystąpił błąd podczas grania w loterię', 'error');
    }
  }

  async function handleBuildingClick(buildingId) {
    try {
      const response = await secureFetch(`${gameUrl}/api/buildings/${buildingId}/upgrade`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Błąd podczas ulepszania budynku');

      const result = await response.json();
      updateUserProgress(result.userProgress);
      updateBuildingsUI(result.buildings);
      updateUIWithUserData();
      showNotification('Budynek został ulepszony!', 'success');
      console.debug('handleBuildingClick wykonane poprawnie');
    } catch (error) {
      console.error('Błąd ulepszania budynku:', error);
      showNotification('Wystąpił błąd podczas ulepszania budynku', 'error');
    }
  }

  async function activateBoost(boostId) {
    try {
      const response = await secureFetch(`${gameUrl}/api/boosts/${boostId}/activate`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Błąd podczas aktywacji boosta');

      const result = await response.json();
      updateUserProgress(result.userProgress);
      updateBoostsUI(result.boosts);
      updateUIWithUserData();
      showNotification('Boost został aktywowany!', 'success');
      console.debug('activateBoost wykonane poprawnie');
    } catch (error) {
      console.error('Błąd aktywacji boosta:', error);
      showNotification('Wystąpił błąd podczas aktywacji boosta', 'error');
    }
  }

  function addEventListeners() {
    elements.rechargeButton.addEventListener('click', rechargeenergia);
    elements.lotteryButton.addEventListener('click', playLottery);

    elements.tabs.forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    document.querySelectorAll('.building').forEach(building => {
      building.addEventListener('click', () => handleBuildingClick(building.dataset.id));
    });

    document.querySelectorAll('.boost').forEach(boost => {
      boost.addEventListener('click', () => activateBoost(boost.dataset.id));
    });
    console.debug('addEventListeners wykonane poprawnie');
  }

  function switchTab(tabName) {
    elements.tabs.forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === tabName);
    });

    elements.tabContents.forEach(content => {
      content.classList.toggle('active', content.id === `${tabName}Content`);
    });
    console.debug('switchTab wykonane poprawnie');
  }
  
  // Funkcja do wyświetlania powiadomień
  function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.remove();
    }, 3000);
  }


  function showModal(title, message) {
    const modal = document.createElement('div');
    modal.classList.add('modal');
    modal.innerHTML = `
      <div class="modal-content">
        <h2>${title}</h2>
        <p>${message}</p>
        <button id="closeModal">Zamknij</button>
      </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('closeModal').addEventListener('click', () => {
      modal.remove();
    });
  }

  function redirectToLoginPage() {
    window.location.href = `${gameUrl}/api/start`;
  }

  async function updateUserDataOnServer() {
    try {
      const response = await secureFetch(`${gameUrl}/api/user/update`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userProgress),
      });

      if (!response.ok) throw new Error('Błąd podczas aktualizacji danych użytkownika');

      const result = await response.json();
      console.log('Dane użytkownika zaktualizowane na serwerze:', result);
    } catch (error) {
      console.error('Błąd aktualizacji danych użytkownika:', error);
      showNotification('Wystąpił błąd podczas aktualizacji danych', 'error');
    }
  }

  function startAutoSave() {
    setInterval(() => {
      updateUserDataOnServer();
    }, 60000); // Zapisuj co minutę
  }

async function initializeGame() {
    try {
        await getSessionIdAndToken();
        await loadUserData();
        addEventListeners();
        switchTab('main');
        startEnergiaInterval();
        startAutoSave();
        startTokenRefreshInterval();
    } catch (error) {
        console.error('Błąd inicjalizacji gry:', error);
        showNotification('Wystąpił błąd podczas ładowania gry', 'error');
    }
}

// Eksportuj funkcję initializeGame, aby była dostępna globalnie
window.initializeGame = initializeGame;