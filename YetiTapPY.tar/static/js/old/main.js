document.addEventListener('DOMContentLoaded', () => {
    const gameUrl = window.location.origin;
    const loadingPage = document.getElementById('loadingPage');
    const gamePage = document.getElementById('gamePage');
    const enterButton = document.getElementById('enterButton');

    const elements = {
        tabs: document.querySelectorAll('.tab'),
        tabContents: document.querySelectorAll('.tab-content'),
        coin: document.getElementById('coin'),
        coinCount: document.getElementById('coinCount'),
        energyFill: document.getElementById('energyFill'),
        levelFill: document.getElementById('levelFill'),
        levelDisplay: document.getElementById('level'),
        energyText: document.getElementById('energyText'),
        levelText: document.getElementById('levelText'),
        rechargeButton: document.getElementById('rechargeButton'),
        lotteryButton: document.getElementById('lotteryButton'),
        gameContainer: document.querySelector('.game-frame'),

    };

    let sessionId = null;
    let energy = 1000;
    const maxEnergy = 1000;
    let level = 1;
    let energyInterval;

    function updateUIWithUserData(userData) {
        elements.levelDisplay.innerText = userData.level;
        elements.coinCount.innerText = userData.coins;
        elements.energyFill.style.width = `${(userData.energy / maxEnergy) * 100}%`;
        elements.energyText.innerText = `${userData.energy} / ${maxEnergy}`;
        const expForNextLevel = 100 * Math.pow(1.5, userData.level - 1);
        elements.levelFill.style.width = `${(userData.experience / expForNextLevel) * 100}%`;
        elements.levelText.innerText = `${userData.experience} / ${expForNextLevel}`;
        energy = userData.energy;
        level = userData.level;
    }

    document.addEventListener('DOMContentLoaded', () => {
        initializeTonConnect();
        initializeEnterButton();
        initializeTabs();
    });

async function initUserData() {
  try {
    const sessionId = localStorage.getItem('session_id');
    const token = localStorage.getItem('token');

    if (!sessionId || !token) {
      return;
    }

    const response = await fetch(`/game?session_id=${sessionId}&token=${token}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (response.ok) {
      const userData = await response.json();
      updateUIWithUserData(userData);
      loadingPage.style.display = 'none';
      gamePage.style.display = 'block';
    } else {
      console.error('Failed to fetch user data:', response.status);
      showModal('Błąd', 'Nie udało się załadować danych użytkownika. Spróbuj ponownie później.');
    }
  } catch (error) {
    console.error('Error fetching user data:', error);
    showModal('Błąd', 'Wystąpił nieoczekiwany błąd. Spróbuj ponownie później.');
  }
}

function initializeEnterButton() {
  // Funkcja do parsowania parametrów z URL
  function getSessionIdAndTokenFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return {
      session_id: urlParams.get('session_id'),
      token: urlParams.get('token'),
    };
  }

  function handleEnterButtonClick() {
    const { session_id, token } = getSessionIdAndTokenFromURL();

    if (session_id && token) {
      // Zapisz session_id i token do localStorage
      localStorage.setItem('session_id', session_id);
      localStorage.setItem('token', token);

      // Symulacja czasu ładowania
      setTimeout(() => {
        initUserData();
      }, 2000);
    } else {
      showModal('Błąd', 'Brak session_id lub tokena w URL.');
    }
  }

  // Przypisz funkcję handleEnterButtonClick do przycisku "Enter"
  enterButton.addEventListener('click', handleEnterButtonClick);
}

elements.coin.addEventListener('click', async (event) => {
  if (energy > 0 && sessionId) {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('User not authenticated');
      }

      const response = await fetch(`${gameUrl}/api/game/click`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'X-Session-ID': sessionId,
        },
      });

      if (response.ok) {
        const data = await response.json();
        updateUIWithUserData(data);

        elements.coin.style.transform = 'scale(1.2)';
        setTimeout(() => {
          elements.coin.style.transform = 'scale(1)';
        }, 100);

        const snowballEffect = document.createElement('div');
        snowballEffect.classList.add('snowballEffect');
        snowballEffect.textContent = `+1`;
        const rect = elements.gameContainer.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;

        snowballEffect.style.left = `${x - 20}px`;
        snowballEffect.style.top = `${y - 20}px`;
        elements.gameContainer.appendChild(snowballEffect);
        setTimeout(() => {
          elements.gameContainer.removeChild(snowballEffect);
        }, 600);

        if (data.level > level) {
          showModal('Gratulacje!', `Osiągnąłeś poziom ${data.level}`);
        }
      } else {
        if (response.status === 401) {
          // Jeśli token jest nieprawidłowy, usuń go z localStorage
          localStorage.removeItem('token');
          console.error('Nieprawidłowy token JWT');
        } else {
          console.error('Failed to update game state');
        }
      }
    } catch (error) {
      console.error('Error updating game state:', error);
    }
  } else if (!sessionId) {
    showModal('Error', 'Game session not initialized. Please restart the game.');
  } else {
    showModal('Brak energii', 'Nie masz wystarczającej energii Poczekaj, aż się naładuje.');
  }
});

    function showModal(title, message) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h2>${title}</h2>
                <p>${message}</p>
                <button onclick="this.parentElement.parentElement.remove()">OK</button>
            </div>
        `;
        document.body.appendChild(modal);
    }

    function rechargeEnergy() {
        const lastRecharge = localStorage.getItem('lastRecharge');
        const now = Date.now();
        if (!lastRecharge || (now - lastRecharge) > 43200000) {
            if (energy < maxEnergy) {
                energy += 100;
                if (energy > maxEnergy) {
                    energy = maxEnergy;
                }
                updateUIWithUserData({energy: energy});
                localStorage.setItem('lastRecharge', now);
                window.open('https://owhaptih.net/4/7598732', '_blank');
            }
        } else {
            showModal('Czas ładowania', 'Możesz ładować energię tylko raz na 12 godzin.');
        }
    }

    elements.rechargeButton.addEventListener('click', rechargeEnergy);

    energyInterval = setInterval(() => {
        if (energy < maxEnergy) {
            energy += 1;
            updateUIWithUserData({energy: energy});
        }
    }, 10000);

    async function fetchLeaderboard() {
        try {
            const token = localStorage.getItem('token');
            if (!token) {
                console.error('Token JWT nie jest dostępny');
                return;
            }

            const response = await fetch(`${gameUrl}/leaderboard`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                const leaderboardList = document.getElementById('leaderboardList');
                leaderboardList.innerHTML = '';
                data.forEach((entry, index) => {
                    const listItem = document.createElement('div');
                    listItem.className = 'leaderboard-item';
                    listItem.textContent = `${index + 1}. ${entry.username} - ${entry.score} pkt`;
                    leaderboardList.appendChild(listItem);
                });
            } else {
                if (response.status === 401) {
                    // Jeśli token jest nieprawidłowy, usuń go z localStorage
                    localStorage.removeItem('token');
                    console.error('Nieprawidłowy token JWT');
                } else {
                    console.error('Failed to fetch leaderboard:', response.status);
                }
            }
        } catch (error) {
            console.error('Error fetching leaderboard:', error);
        }
    }

    function checkAuth() {
        const token = localStorage.getItem('token');
        if (token) {
            elements.enterButton.style.display = 'none';
            elements.gameContainer.style.display = 'block';
            loadUserData();
        } else {
            elements.enterButton.style.display = 'block';
            elements.gameContainer.style.display = 'none';
        }
    }

    function unlockGame() {
        elements.enterButton.style.display = 'none';
        elements.gameContainer.style.display = 'block';
        loadUserData();
    }

    function initializeGame() {
        checkAuth();
        fetchLeaderboard();
        setInterval(fetchLeaderboard, 60000);
    }

    initializeGame();
});
document.addEventListener('DOMContentLoaded', () => {
    const { session_id, token } = getSessionIdAndTokenFromURL();
    if (session_id && token) {
        loadUserData(session_id, token);
    } else {
        console.error('Session ID or token not found in URL');
    }

    setupTabNavigation();
    setupShopFunctionality();
});

function getSessionIdAndTokenFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    const session_id = urlParams.get('session_id');
    const token = urlParams.get('token');
    const tgWebAppData = parseTgWebAppData(window.location.hash);
    // Additional logic to handle tgWebAppData if needed
    return { session_id, token };
}

function parseTgWebAppData(hash) {
    const hashParams = new URLSearchParams(hash.substring(1));
    return {
        query_id: hashParams.get('tgWebAppData-query_id'),
        user: JSON.parse(decodeURIComponent(hashParams.get('user') || '{}')),
        auth_date: hashParams.get('auth_date'),
        hash: hashParams.get('hash')
    };
}


    function buyItem(itemId) {
        const { session_id, token } = getSessionIdAndTokenFromURL();
        fetch(`/buy-item`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ itemId, session_id })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Item purchased successfully!');
                loadUserData(session_id, token);
            } else {
                alert('Error purchasing item: ' + data.message);
            }
        })
        .catch(error => console.error('Error purchasing item:', error));
    }


async function handleStartCommand(userId) {
    const { session_id, token } = getSessionIdAndTokenFromURL();
    try {
        const response = await fetch(`/api/start_session?token=${token}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ user_id: userId, session_id })
        });

        const data = await response.json();
        if (data.session_id) {
            localStorage.setItem('session_id', data.session_id);
            localStorage.setItem('token', data.token);
            // Redirect user to the game page
            window.location.href = `/game?session_id=${data.session_id}&token=${data.token}`;
        } else {
            console.error('Session creation failed');
        }
    } catch (error) {
        console.error('Error starting session:', error);
        alert('An error occurred while starting the session. Please try again later.');
    }
}