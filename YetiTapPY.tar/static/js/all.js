// Configuration
const config = {
    gameUrl: window.location.origin,
    tokenRefreshInterval: 60000, // 1 minuta
    tokenRefreshThreshold: 300000, // 5 minut przed wygaśnięciem
    notificationDuration: 3000, // 3 sekundy
    maxRetries: 3,
    retryDelay: 100, // 1 sekunda
    energyRegenerationInterval: 1000 // 1 minuta
};
const DirectLink = "https://t.me/YetiCoin_Bot/YetiCoin";
const Description = "YetiCoinTap is an innovative blockchain-based game integrated directly with Telegram, leveraging the TON (The Open Network) blockchain for secure and swift transactions. This 'clicker' game allows players to earn rewards by simply tapping on a coin, making it both easy to play and highly engaging.";
const WebAppURL = "https://t.me/YetiCoin_Bot?start=game";

// Telegram WebApp setup and game state management
const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
const gameState = {
    sessionId: null,
    token: null,
    userProgress: null
};

// Middleware for API requests
class ApiMiddleware {
    constructor(baseUrl, maxRetries = 3, retryDelay = 1000) {
        this.baseUrl = baseUrl;
        this.maxRetries = maxRetries;
        this.retryDelay = retryDelay;
    }

    async get(endpoint, options = {}) {
        return this._request('GET', endpoint, options);
    }

    async post(endpoint, options = {}) {
        return this._request('POST', endpoint, options);
    }

    async _request(method, endpoint, options) {
        const url = `${this.baseUrl}/api${endpoint}`;
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };

        const { sessionId, token } = getGameState();
        if (sessionId) {
            headers['X-Session-ID'] = sessionId;
        }
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        for (let i = 0; i <= this.maxRetries; i++) {
            try {
                const response = await fetch(url, {
                    method,
                    headers,
                    ...options
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.error || 'Unknown error'}`);
                }

                return response.json();
            } catch (error) {
                logWithTimestamp(`Error in API request (attempt ${i + 1}): ${error.message}`, 'error');
                if (i === this.maxRetries) {
                    throw error; // Re-throw the error after max retries
                }
                await new Promise(resolve => setTimeout(resolve, this.retryDelay));
            }
        }
    }
}

// Create API middleware instance
const apiMiddleware = new ApiMiddleware(config.gameUrl, config.maxRetries, config.retryDelay);

function updateGameState(newState) {
    Object.assign(gameState, newState);
}

function getGameState() {
    return { ...gameState };
}

// DOM Elements
const elements = {
    tabs: document.querySelectorAll('.tab'),
    tabContents: document.querySelectorAll('.tab-content'),
    coin: document.getElementById('coin'),
    coinCount: document.getElementById('coinCountElement'),
    energiaFill: document.getElementById('energiaFill'),
    levelFill: document.getElementById('levelFill'),
    levelDisplay: document.getElementById('levelElement'),
    energiaText: document.getElementById('energiaText'),
    levelText: document.getElementById('levelText'),
    rechargeButton: document.getElementById('rechargeButton'),
    gameContainer: document.querySelector('.game-frame'),
    usernameElement: document.getElementById('usernameElement'),
    maxEnergiaElement: document.getElementById('maxEnergiaElement'),
    experienceElement: document.getElementById('experienceElement')
};

// Utility Functions
function logWithTimestamp(message, level = 'info') {
    const timestamp = new Date().toISOString();
    console[level](`[${timestamp}] ${message}`);
}

function trackPerformance(functionName, startTime) {
    const duration = performance.now() - startTime;
    logWithTimestamp(`${functionName} executed in ${duration.toFixed(2)}ms`, 'debug');
}

function sanitizeInput(input) {
    return DOMPurify.sanitize(input);
}
function showNotification(title, message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `<strong>${sanitizeInput(title)}</strong><p>${sanitizeInput(message)}</p>`;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, config.notificationDuration);
}

function showModal(title, message, buttons = []) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    let buttonHtml = buttons.length > 0 
        ? '<div class="modal-buttons">' + buttons.map(button => `<button class="${button.class}">${button.text}</button>`).join('') + '</div>'
        : '<button class="close-button">Zamknij</button>';
    
    modal.innerHTML = `
        <div class="modal-content">
            <h2>${sanitizeInput(title)}</h2>
            <p>${sanitizeInput(message)}</p>
            ${buttonHtml}
        </div>
    `;
    document.body.appendChild(modal);

    const closeButton = modal.querySelector('.close-button');
    if (closeButton) {
        closeButton.addEventListener('click', () => modal.remove());
    }
    buttons.forEach((button, index) => {
        const btnElement = modal.querySelectorAll('.modal-buttons button')[index];
        btnElement.addEventListener('click', () => {
            button.onClick();
            modal.remove();
        });
    });
}

function showModal2(title, message) {
    const modal = document.createElement('div');
    modal.className = 'modal2';
    modal.innerHTML = `
        <div class="modal2-content">
            <h2>${sanitizeInput(title)}</h2>
            <p>${sanitizeInput(message)}</p>
            <div class="modal2-buttons">
                <button class="close-button">Zamknij</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    const closeButton = modal.querySelector('.close-button');

    closeButton.addEventListener('click', () => {
        document.body.removeChild(modal);
    });

    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

// Storage Functions
const storage = {
    set: (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            sessionStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            logWithTimestamp(`Error setting storage item: ${e}`, 'error');
        }
    },
    get: (key) => {
        const value = sessionStorage.getItem(key) || localStorage.getItem(key);
        try {
            return value ? JSON.parse(value) : null;
        } catch (e) {
            logWithTimestamp(`Error parsing storage item: ${e}`, 'error');
            return null;
        }
    },
    remove: (key) => {
        try {
            localStorage.removeItem(key);
            sessionStorage.removeItem(key);
        } catch (e) {
            logWithTimestamp(`Error removing storage item: ${e}`, 'error');
        }
    }
};

// API Functions
async function secureFetch(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    const { sessionId, token } = getGameState();

    if (sessionId) {
        headers['X-Session-ID'] = sessionId;
    }

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    try {
        const response = await fetch(url, {
            ...options,
            headers: headers
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response;
    } catch (error) {
        logWithTimestamp(`Error in secureFetch: ${error.message}`, 'error');
        throw error;
    }
}

async function getSessionIdAndToken() {
    const coinElement = document.getElementById('coin');
    const sessionId = coinElement.dataset.sessionId;
    const token = coinElement.dataset.token;

    if (sessionId && token) {
        storage.set('sessionId', sessionId);
        storage.set('token', token);
        updateGameState({ sessionId, token });
        return { sessionId, token };
    } else {
        logWithTimestamp('Session ID or token not found in coin element', 'warn');
        return null;
    }
}

async function loadUserData() {
    try {
        const data = await apiMiddleware.post('/user/stats');
        updateGameState({ userProgress: data });
        updateUI(data);
        return true;
    } catch (error) {
        logWithTimestamp(`Error loading user data: ${error.message}`, 'error');
        showNotification('Error', 'Failed to load user data. Please try again later.', 'error');
        return false;
    }
}

async function updateUserData() {
    const { sessionId, userProgress } = getGameState();
    try {
        await apiMiddleware.post('/user/update', {
            body: JSON.stringify({ ...userProgress, sessionId })
        });
        logWithTimestamp('User data updated on server');
    } catch (error) {
        logWithTimestamp(`Error updating user data: ${error.message}`, 'error');
    }
}



// Funkcja do obliczania wymaganego doświadczenia dla danego poziomu
function calculateExpForLevel(level) {
    return Math.floor(100 * Math.pow(1.5, level - 1));
}

// Funkcja do obliczania całkowitego doświadczenia potrzebnego do osiągnięcia danego poziomu
function calculateTotalExpForLevel(level) {
    let totalExp = 0;
    for (let i = 1; i < level; i++) {
        totalExp += calculateExpForLevel(i);
    }
    return totalExp;
}

// Funkcja do obliczania aktualnego postępu doświadczenia w bieżącym poziomie
function calculateCurrentLevelProgress(experience, level) {
    const totalExpForCurrentLevel = calculateTotalExpForLevel(level);
    return experience - totalExpForCurrentLevel;
}

function updateUI(userData) {
    if (!userData) {
        logWithTimestamp('User progress data is not available', 'warn');
        return;
    }

    const { energia, max_energia, level, experience, coins } = userData;
    const expForCurrentLevel = calculateExpForLevel(level);
    const expForNextLevel = calculateExpForLevel(level + 1);
    const currentLevelProgress = calculateCurrentLevelProgress(experience, level);
    const expNeeded = expForCurrentLevel - currentLevelProgress;

    // Aktualizacja paska energii
    if (elements.energiaFill) {
        elements.energiaFill.style.width = `${(energia / max_energia) * 100}%`;
    }
    if (elements.energiaText) {
        elements.energiaText.innerHTML = `<span id="energiaElement">${energia}</span> / <span id="maxEnergiaElement">${max_energia}</span>`;
    }

    // Aktualizacja paska doświadczenia
    if (elements.levelFill) {
        elements.levelFill.style.width = `${(currentLevelProgress / expForCurrentLevel) * 100}%`;
    }
    if (elements.levelText) {
        elements.levelText.innerHTML = `<span id="experienceElement">${currentLevelProgress} / ${expForCurrentLevel}</span>`;
    }

    // Aktualizacja szczegółów doświadczenia
    const expDetailsElement = document.querySelector('.exp-details');
    if (expDetailsElement) {
        const expPercentage = ((currentLevelProgress / expForCurrentLevel) * 100).toFixed(2);
        expDetailsElement.innerHTML = `
            <span class="exp-percentage">${expPercentage}%</span>
            <span class="exp-to-next">${expNeeded} do następnego poziomu</span>
        `;
    }

    // Aktualizacja innych elementów
    if (elements.coinCount) elements.coinCount.textContent = coins;
    if (elements.levelDisplay) elements.levelDisplay.textContent = level;

}

// Funkcja do sprawdzania i obsługi awansu na wyższy poziom
function checkLevelUp() {
    const { userProgress } = getGameState();
    let leveledUp = false;
    let levelsGained = 0;
    
    while (userProgress.experience >= calculateTotalExpForLevel(userProgress.level + 1)) {
        userProgress.level++;
        levelsGained++;
        userProgress.max_energia += 5;
        userProgress.energia = userProgress.max_energia;
        leveledUp = true;
    }
    
    if (leveledUp) {
        updateGameState({ userProgress });
        showModal2('Gratulacje!', `Osiągnąłeś poziom ${userProgress.level}! Awansowałeś o ${levelsGained} ${levelsGained === 1 ? 'poziom' : 'poziomy'}. Twoja energia została odnowiona.`);
        updateUI(userProgress);
    }
}

function initializeCoinClicking() {
    const coin = document.getElementById('coin');
    const clickArea = document.createElement('div');

    // Style clickable area
    clickArea.style.position = 'absolute';
    clickArea.style.width = '70%';
    clickArea.style.height = '70%';
    clickArea.style.left = '15%';
    clickArea.style.top = '15%';
    clickArea.style.cursor = 'pointer';
    clickArea.style.zIndex = '100';
    clickArea.style.userSelect = 'none'; // Zapobiega zaznaczaniu

    coin.style.position = 'relative';
    coin.style.transition = 'transform 0.1s ease-in-out';
    coin.appendChild(clickArea);

    clickArea.addEventListener('mousedown', (e) => {
        e.preventDefault();
        coin.style.transform = 'scale(0.95)';
    });

    clickArea.addEventListener('mouseup', (e) => {
        e.preventDefault();
        coin.style.transform = 'scale(1)';
    });

    clickArea.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const { userProgress } = getGameState();
        if (!userProgress) {
            logWithTimestamp('User progress not initialized', 'error');
            return;
        }

        if (userProgress.energia <= 0) {
            showModal('Brak energii', 'Nie masz wystarczającej ilości energii. Poczekaj na regenerację lub użyj przedmiotu regenerującego.');
            return;
        }

        const actualMultiplier = 1;

        // Animacja obrotu monety
        coin.animate([
            { transform: 'rotateY(0deg)' },
            { transform: 'rotateY(180deg)' },
            { transform: 'rotateY(360deg)' }
        ], {
            duration: 300,
            easing: 'ease-in-out'
        });

        // Wyzwalamy animację błysku monety
        const shine = document.createElement('div');
        shine.style.position = 'absolute';
        shine.style.top = '0';
        shine.style.left = '0';
        shine.style.width = '100%';
        shine.style.height = '100%';
        shine.style.background = 'radial-gradient(circle, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 70%)';
        shine.style.opacity = '0';
        shine.style.pointerEvents = 'none';
        coin.appendChild(shine);

        shine.animate([
            { opacity: 0 },
            { opacity: 1 },
            { opacity: 0 }
        ], {
            duration: 300,
            easing: 'ease-in-out'
        });

        setTimeout(() => {
            shine.remove();
        }, 300);

        const updatedProgress = {
            ...userProgress,
            coins: userProgress.coins + actualMultiplier,
            experience: userProgress.experience + actualMultiplier,
            energia: Math.max(userProgress.energia - 1, 0)
        };

        updateGameState({ userProgress: updatedProgress });
        checkLevelUp();
        updateUI(updatedProgress);
        createSnowballEffect(coin, actualMultiplier);

        await updateUserData();
    });
}

function createSnowballEffect(coin, multiplier) {
    const coinRect = coin.getBoundingClientRect();
    const gameArea = document.getElementById('game');
    const snowball = document.createElement('div');
    snowball.classList.add('snowballEffect');
    snowball.textContent = `+${multiplier}`;
    snowball.style.position = 'absolute';
    snowball.style.fontSize = '20px';
    snowball.style.fontWeight = 'bold';
    snowball.style.color = '#FFD700';
    snowball.style.textShadow = '0 0 3px #000';
    snowball.style.pointerEvents = 'none';

    const rangeFactor = 0.2;

    const randomX = (Math.random() - 0.5) * rangeFactor * coinRect.width;
    const randomY = (Math.random() - 0.5) * rangeFactor * coinRect.height;

    snowball.style.left = `${coinRect.left + coinRect.width / 2 + randomX}px`;
    snowball.style.top = `${coinRect.top + coinRect.height / 2 + randomY}px`;
    snowball.style.transform = 'translate(-50%, -50%) scale(0)';
    gameArea.appendChild(snowball);

    const deviationX = (Math.random() - 0.5) * 30;
    const deviationY = -50 - Math.random() * 30; // Zawsze w górę

    snowball.animate([
        { transform: 'translate(-50%, -50%) scale(0)', opacity: 0 },
        { transform: 'translate(-50%, -50%) scale(1.2)', opacity: 1, offset: 0.2 },
        { transform: `translate(calc(-50% + ${deviationX}px), calc(-50% + ${deviationY}px)) scale(1)`, opacity: 1, offset: 0.8 },
        { transform: `translate(calc(-50% + ${deviationX}px), calc(-50% + ${deviationY}px)) scale(0)`, opacity: 0 }
    ], {
        duration: 800,
        easing: 'ease-out'
    });

    setTimeout(() => {
        snowball.remove();
    }, 800);
}

function regenerateEnergy() {
    setInterval(() => {
        const { userProgress } = getGameState();
        if (userProgress && userProgress.energia < userProgress.max_energia) {
            const updatedProgress = {
                ...userProgress,
                energia: Math.min(userProgress.energia + 1, userProgress.max_energia)
            };
            updateGameState({ userProgress: updatedProgress });
            updateUI(updatedProgress);
            updateUserData(); // Dodane, aby zaktualizować dane na serwerze
        }
    }, config.energyRegenerationInterval);
}

function displayError(message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    document.body.appendChild(errorElement);
}

// Tab Functions
// Funkcja loadFile powinna być zdefiniowana gdzie indziej w kodzie
function loadFile() {
    // Implementacja ładowania pliku
    console.log('Ładowanie pliku dla zakładki "hop"');
}

// App Initialization
async function initializeApp() {
    try {
        const sessionData = await getSessionIdAndToken();
        if (!sessionData) {
            throw new Error('Invalid session or token');
        }

        const userDataLoaded = await loadUserData();
        if (!userDataLoaded) {
            throw new Error('Failed to load user data');
        }

        if (tg && tg.__telegram__initParams) {
            tg.__telegram__initParams = {
                ...tg.__telegram__initParams,
                session_id: sessionData.sessionId,
                token: sessionData.token
            };
        }

        initializeCoinClicking();
        regenerateEnergy();
        logWithTimestamp('App initialized successfully');
    } catch (error) {
        logWithTimestamp(`Error initializing app: ${error.message}`, 'error');
        displayError(`Cannot initialize app: ${error.message}`);
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', async () => {
    const startTime = performance.now();

    try {
        await initializeApp();
    } catch (error) {
        logWithTimestamp(`Error in DOMContentLoaded: ${error.message}`, 'error');
        displayError(`Error loading app: ${error.message}`);
    } finally {
        trackPerformance('DOMContentLoaded', startTime);
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;

    function applyThemeParams(themeParams) {
        if (themeParams) {
            Object.entries(themeParams).forEach(([key, value]) => {
                document.documentElement.style.setProperty(`--tg-${key}`, value);
            });
        }
    }

    if (tg) {
        // Informujemy, że WebApp jest gotowy do wyświetlenia
        tg.ready();

        // Rozwijamy WebApp do maksymalnej wysokości
        tg.expand();
        tg.disableClosingConfirmation();

        function parseTelegramInitData() {
            try {
                console.log("Telegram initData:", window.Telegram.WebApp.initData);
                return JSON.parse(window.Telegram.WebApp.initData);
            } catch (error) {
                console.error('Error parsing Telegram init data:', error);
                return {};
            }
        }

        function updateTelegramParams(sessionData) {
            if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.setParams({
                    session_id: sessionData.sessionId,
                    token: sessionData.token
                });
            } else {
                console.warn('Telegram WebApp object not found');
            }
        }

        function updateLastVisit() {
            const currentDate = new Date().toISOString();

            // Zapisz datę w SessionStorage
            sessionStorage.setItem('lastVisit', currentDate);

            // Zapisz datę w CloudStorage
            tg.CloudStorage.setItem('lastVisit', currentDate, (error) => {
                if (error) {
                    console.error('Błąd zapisu do CloudStorage:', error);
                } else {
                    console.log('Data ostatniej wizyty zapisana w CloudStorage');
                }
            });
        }

        function checkLastVisit() {
            // Sprawdź SessionStorage
            const sessionLastVisit = sessionStorage.getItem('lastVisit');

            if (sessionLastVisit) {
                updateLastVisit();
            } else {
                // Jeśli brak w SessionStorage, sprawdź CloudStorage
                tg.CloudStorage.getItem('lastVisit', (error, cloudLastVisit) => {
                    if (error) {
                        console.error('Błąd odczytu z CloudStorage:', error);
                        updateLastVisit();
                    } else if (cloudLastVisit) {
                        updateLastVisit();
                    } else {
                        tg.showAlert('To Twoja pierwsza wizyta!');
                        updateLastVisit();
                    }
                });
            }
        }

        // Wywołaj funkcję przy każdym uruchomieniu aplikacji
        checkLastVisit();

        // Apply initial theme
        applyThemeParams(tg.themeParams);

        // Obsługa zdarzenia zmiany motywu
        tg.onEvent('themeChanged', (themeParams) => {
            applyThemeParams(themeParams);
        });

        // Handle expansion and viewport changes
        function setFullscreenMode() {
            const viewportHeight = tg.viewportHeight || window.innerHeight;
            const viewportStableHeight = tg.viewportStableHeight || window.innerHeight;

            document.documentElement.style.setProperty('--tg-viewport-height', `${viewportHeight}px`);
            document.documentElement.style.setProperty('--tg-viewport-stable-height', `${viewportStableHeight}px`);

            document.body.style.height = `${viewportHeight}px`;

            // Log the expanded state
            console.log("isExpanded:", tg.isExpanded);
        }

        setFullscreenMode(); // Initial call

        // Update on viewport changes
        tg.onEvent('viewportChanged', () => {
            setFullscreenMode();
        });

        // Add styles to CSS
        document.head.insertAdjacentHTML('beforeend', `
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    overflow-x: hidden;
                }
                #app {
                    min-height: var(--tg-viewport-height, 100vh);
                    width: 100vw;
                    overflow-x: hidden;
                }
            </style>
        `);
    } else {
        console.warn('Telegram WebApp jest niedostępny');

        // Symulacja środowiska Telegram
        window.Telegram = {
            WebApp: {
                ready: () => console.log('WebApp ready'),
                expand: () => console.log('WebApp expanded'),
                disableClosingConfirmation: () => console.log('Closing confirmation disabled'),
                MainButton: {
                    setText: (text) => console.log('MainButton text set:', text),
                    show: () => console.log('MainButton shown'),
                    onClick: (callback) => document.getElementById('mainButton').addEventListener('click', callback)
                },
                BackButton: {
                    show: () => console.log('BackButton shown'),
                    onClick: (callback) => document.getElementById('backButton').addEventListener('click', callback)
                },
                showPopup: (params, callback) => {
                    console.log('Showing popup:', params);
                    if (callback) callback('play');
                },
                showAlert: (message) => alert(message),
                themeParams: {
                    bg_color: '#ffffff',
                    text_color: '#000000',
                    hint_color: '#999999',
                    link_color: '#2481cc',
                    button_color: '#5288c1',
                    button_text_color: '#ffffff',
                    header_bg_color: '#ffffff',
                    accent_text_color: '#2481cc',
                    section_bg_color: '#f0f0f0',
                    section_header_text_color: '#2481cc',
                    subtitle_text_color: '#999999',
                    destructive_text_color: '#ff0000'
                },
                onEvent: (event, callback) => {
                    if (event === 'themeChanged') {
                        // Symulacja zmiany motywu po 5 sekundach
                        setTimeout(() => {
                            callback({
                                bg_color: '#1c1c1c',
                                text_color: '#ffffff',
                                hint_color: '#aaaaaa',
                                link_color: '#8ec3ff',
                                button_color: '#50a8eb',
                                button_text_color: '#ffffff',
                                header_bg_color: '#2c2c2c',
                                accent_text_color: '#8ec3ff',
                                section_bg_color: '#2c2c2c',
                                section_header_text_color: '#8ec3ff',
                                subtitle_text_color: '#aaaaaa',
                                destructive_text_color: '#ff5555'
                            });
                        }, 5000);
                    } else if (event === 'viewportChanged') {
                        // Symulacja zmiany viewportu po 5 sekundach
                        setTimeout(() => {
                            window.Telegram.WebApp.viewportHeight = window.innerHeight / 2;
                            window.Telegram.WebApp.viewportStableHeight = window.innerHeight / 2;
                            window.Telegram.WebApp.isExpanded = false;
                            setFullscreenMode();
                        }, 5000);
                    }
                },
                close: () => console.log('WebApp closed'),
                CloudStorage: {
                    getItem: (key, callback) => {
                        const value = localStorage.getItem(key);
                        callback(null, value);
                    },
                    setItem: (key, value) => {
                        localStorage.setItem(key, value);
                    }
                }
            }
        };

        // Dodanie symulowanych przycisków do DOM
        const buttonsContainer = document.createElement('div');
        buttonsContainer.innerHTML = `
            <button id="mainButton" style="position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); z-index: 1000;">Main Button</button>
            <button id="backButton" style="position: fixed; top: 20px; left: 20px; z-index: 1000;">Back</button>
        `;
        document.body.appendChild(buttonsContainer);
    }
});


document.getElementById('lotteryButton').addEventListener('click', playLottery);

// Funkcja do sprawdzania i aktualizacji czasu loterii
async function checkAndUpdateLotteryTime() {
    const cooldownPeriod = 24 * 60 * 60 * 1000; // 24 godziny w milisekundach
    const currentTime = Date.now();

    return new Promise((resolve) => {
        tg.CloudStorage.getItem('lastLotteryPlay', (error, lastPlayTime) => {
            if (error) {
                console.error('Błąd odczytu z CloudStorage:', error);
                resolve(true); // Pozwalamy na grę w przypadku błędu
            } else {
                if (lastPlayTime && currentTime - parseInt(lastPlayTime) < cooldownPeriod) {
                    const remainingTime = cooldownPeriod - (currentTime - parseInt(lastPlayTime));
                    const hours = Math.floor(remainingTime / (60 * 60 * 1000));
                    const minutes = Math.floor((remainingTime % (60 * 60 * 1000)) / (60 * 1000));
                    tg.showAlert(`Możesz zagrać ponownie za ${hours} godzin i ${minutes} minut.`);
                    resolve(false);
                } else {
                    // Aktualizuj czas ostatniego użycia loterii
                    tg.CloudStorage.setItem('lastLotteryPlay', currentTime.toString(), (setError) => {
                        if (setError) {
                            console.error('Błąd zapisu do CloudStorage:', setError);
                        }
                        resolve(true);
                    });
                }
            }
        });
    });
}

// Zaktualizowana funkcja playLottery
async function playLottery() {
    const canPlay = await checkAndUpdateLotteryTime();
    if (!canPlay) return;

    tg.showPopup({
        title: 'Loteria YetiCoin',
        message: 'Czy na pewno chcesz wykorzystać 1 los loterii?',
        buttons: [
            {id: 'play', type: 'ok', text: 'Tak, zagraj'},
            {id: 'cancel', type: 'cancel', text: 'Anuluj'}
        ]
    }, (buttonId) => {
        if (buttonId === 'play') {
            const prizes = [
                { label: '500 YetiCoin', probability: 0.01, color: '#FFD700', amount: 500 },
                { label: '200 YetiCoin', probability: 0.03, color: '#E5E4E2', amount: 200 },
                { label: '100 YetiCoin', probability: 0.05, color: '#FFA500', amount: 100 },
                { label: '50 YetiCoin', probability: 0.1, color: '#C0C0C0', amount: 50 },
                { label: '20 YetiCoin', probability: 0.15, color: '#CD7F32', amount: 20 },
                { label: '10 YetiCoin', probability: 0.2, color: '#4CAF50', amount: 10 },
                { label: '5 YetiCoin', probability: 0.25, color: '#87CEEB', amount: 5 },
                { label: 'Brak nagrody', probability: 0.21, color: '#FF5733', amount: 0 }
            ];
            showWheelOfFortune(prizes);
        }
    });
}

function showWheelOfFortune(prizes) {
    const overlay = createOverlay();
    const modalContent = createModalContent();
    const canvas = createCanvas(modalContent);
    const ctx = canvas.getContext('2d');
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = 140;

    drawWheel(ctx, centerX, centerY, radius, prizes);

    const result = spinWheel(prizes);
    animateWheel(ctx, centerX, centerY, radius, prizes, result, overlay, modalContent);
}

function createOverlay() {
    const overlay = document.createElement('div');
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
        z-index: 999;
    `;
    document.body.appendChild(overlay);
    return overlay;
}

function createModalContent() {
    const modalContent = document.createElement('div');
    modalContent.id = 'modal-content';
    modalContent.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: ${tg.themeParams.secondary_bg_color || '#ffffff'};
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        z-index: 1000;
        text-align: center;
    `;
    document.body.appendChild(modalContent);

    const title = document.createElement('h2');
    title.textContent = 'Koło Fortuny YetiCoin';
    title.style.cssText = `
        color: ${tg.themeParams.text_color || '#000000'};
        margin-bottom: 15px;
    `;
    modalContent.appendChild(title);

    return modalContent;
}
function createCanvas(modalContent) {
    const canvas = document.createElement('canvas');
    canvas.width = 340;  // Zwiększono szerokość
    canvas.height = 360; // Zwiększono wysokość, aby zmieścić wskaźnik
    modalContent.appendChild(canvas);
    return canvas;
}

function drawWheel(ctx, centerX, centerY, radius, prizes, angle = 0) {
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(angle);

    let startAngle = 0;
    prizes.forEach(prize => {
        const sliceAngle = 2 * Math.PI * prize.probability;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, radius, startAngle, startAngle + sliceAngle);
        ctx.fillStyle = prize.color;
        ctx.fill();
        ctx.stroke();
        
        ctx.save();
        ctx.rotate(startAngle + sliceAngle / 2);
        ctx.textAlign = "right";
        ctx.fillStyle = "white";
        ctx.font = "bold 12px Arial";
        ctx.fillText(prize.label, radius - 10, 0);
        ctx.restore();

        startAngle += sliceAngle;
    });

    ctx.restore();

    // Rysowanie wskaźnika u góry
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - radius - 20);
    ctx.lineTo(centerX - 10, centerY - radius - 10);
    ctx.lineTo(centerX + 10, centerY - radius - 10);
    ctx.fillStyle = "red";
    ctx.fill();
}

function spinWheel(prizes) {
    const random = Math.random();
    let cumulativeProbability = 0;
    return prizes.find(prize => {
        cumulativeProbability += prize.probability;
        return random <= cumulativeProbability;
    });
}

function animateWheel(ctx, centerX, centerY, radius, prizes, result, overlay, modalContent) {
    let angle = 0;
    const spinDuration = 8000; // Zwiększono do 8 sekund
    const startTime = Date.now();
    const totalRotation = 15 * Math.PI + (Math.random() * Math.PI * 4); // Zwiększono liczbę obrotów i losowość

    function spin() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / spinDuration, 1);
        angle = easeOutQuint(progress) * totalRotation;

        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
        drawWheel(ctx, centerX, centerY, radius, prizes, angle);

        if (progress < 1) {
            requestAnimationFrame(spin);
        } else {
            setTimeout(() => {
                document.body.removeChild(overlay);
                document.body.removeChild(modalContent);
                showResult(result);
            }, 1000);
        }
    }

    spin();
}

// Nowa funkcja ease dla płynniejszego zatrzymania
function easeOutQuint(t) {
    return 1 - Math.pow(1 - t, 5);
}

function showResult(result) {
    const resultModal = document.createElement('div');
    resultModal.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: ${tg.themeParams.secondary_bg_color || '#ffffff'};
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        z-index: 1000;
        text-align: center;
    `;
    
    const resultText = document.createElement('p');
    resultText.textContent = `Gratulacje! Wygrałeś ${result.label}`;
    resultText.style.cssText = `
        color: ${tg.themeParams.text_color || '#000000'};
        font-size: 18px;
        margin-bottom: 15px;
    `;
    
    const closeButton = document.createElement('button');
    closeButton.textContent = 'Zamknij';
    closeButton.style.cssText = `
        background-color: ${tg.themeParams.button_color || '#3390ec'};
        color: ${tg.themeParams.button_text_color || '#ffffff'};
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    `;
    closeButton.onclick = () => {
        document.body.removeChild(resultModal);
        updateUserBalance(result.amount);
    };
    
    resultModal.appendChild(resultText);
    resultModal.appendChild(closeButton);
    document.body.appendChild(resultModal);
}


async function updateUserBalance(amount) {
    try {
        const progress = await loadUserData();
        progress.coins += amount;
        await updateGameState(progress);
        updateUI(progress);
        tg.showAlert(`Twoje nowe saldo: ${progress.coins} YetiCoin`);
    } catch (error) {
        console.error('Error updating balance:', error);
        tg.showAlert('Wystąpił błąd przy aktualizacji salda. Spróbuj ponownie później.');
    }
}


