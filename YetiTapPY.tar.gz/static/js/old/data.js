document.addEventListener('DOMContentLoaded', () => {
    const { session_id, token } = getSessionIdAndTokenFromURL();
    if (session_id && token) {
        loadUserData(session_id, token);
    } else {
        console.error('Session ID or token not found in URL');
    }

    setupTabNavigation();
    setupShopFunctionality();
});

function getSessionIdAndTokenFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    const session_id = urlParams.get('session_id');
    const token = urlParams.get('token');
    const tgWebAppData = parseTgWebAppData(window.location.hash);
    // Additional logic to handle tgWebAppData if needed
    return { session_id, token };
}

function parseTgWebAppData(hash) {
    const hashParams = new URLSearchParams(hash.substring(1));
    return {
        query_id: hashParams.get('tgWebAppData-query_id'),
        user: JSON.parse(decodeURIComponent(hashParams.get('user') || '{}')),
        auth_date: hashParams.get('auth_date'),
        hash: hashParams.get('hash')
    };
}


function setupTabNavigation() {
    const iframeContainer = document.getElementById('iframeContainer');
    
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const tabName = tab.getAttribute('data-tab');
            if (tabName === 'game') {
                iframeContainer.innerHTML = `<iframe id="gameIframe" src="${window.GAME_URL}" frameborder="0" allowfullscreen></iframe>`;
            } else if (tabName === 'shop') {
                loadShop();
            }
            document.querySelectorAll('.tab-content').forEach(content => {
                content.style.display = content.id === `${tabName}Page` ? 'block' : 'none';
            });
        });
    });
}

function setupShopFunctionality() {
    function loadShop() {
        fetch('/shop-items')
            .then(response => response.json())
            .then(items => {
                const shopContainer = document.querySelector('.shop-container');
                shopContainer.innerHTML = '';
                items.forEach(item => {
                    const itemElement = document.createElement('div');
                    itemElement.classList.add('shop-item');
                    itemElement.innerHTML = `
                        <img src="${item.image}" alt="${item.name}">
                        <h3>${item.name}</h3>
                        <p>${item.price} YetiCoin</p>
                        <button class="buy-button" data-item-id="${item.id}">Buy</button>
                    `;
                    shopContainer.appendChild(itemElement);
                });
                document.querySelectorAll('.buy-button').forEach(button => {
                    button.addEventListener('click', () => {
                        const itemId = button.getAttribute('data-item-id');
                        buyItem(itemId);
                    });
                });
            })
            .catch(error => console.error('Error loading shop items:', error));
    }

    function buyItem(itemId) {
        const { session_id, token } = getSessionIdAndTokenFromURL();
        fetch(`/buy-item`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ itemId, session_id })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Item purchased successfully!');
                loadUserData(session_id, token);
            } else {
                alert('Error purchasing item: ' + data.message);
            }
        })
        .catch(error => console.error('Error purchasing item:', error));
    }
}

async function handleStartCommand(userId) {
    const { session_id, token } = getSessionIdAndTokenFromURL();
    try {
        const response = await fetch(`/api/start_session?token=${token}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ user_id: userId, session_id })
        });

        const data = await response.json();
        if (data.session_id) {
            localStorage.setItem('session_id', data.session_id);
            localStorage.setItem('token', data.token);
            // Redirect user to the game page
            window.location.href = `/game?session_id=${data.session_id}&token=${data.token}`;
        } else {
            console.error('Session creation failed');
        }
    } catch (error) {
        console.error('Error starting session:', error);
        alert('An error occurred while starting the session. Please try again later.');
    }
}