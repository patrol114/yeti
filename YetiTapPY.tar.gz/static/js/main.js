// Combined Configuration
const config = {
    gameUrl: window.location.origin,
    tokenRefreshInterval: 60000, // 1 minute
    tokenRefreshThreshold: 300000, // 5 minutes before expiration
    notificationDuration: 3000, // 3 seconds
    maxRetries: 3,
    retryDelay: 1000, // 1 second
    energyRegenerationInterval: 5000 // 5 seconds
};
// Telegram WebApp setup
const tg = window.Telegram.WebApp;

// Game State Management
const gameState = {
    sessionId: null,
    token: null,
    userProgress: null
};

function updateGameState(newState) {
    Object.assign(gameState, newState);
}

function getGameState() {
    return { ...gameState };
}

// DOM Elements
const elements = {
    tabs: document.querySelectorAll('.tab'),
    tabContents: document.querySelectorAll('.tab-content'),
    coin: document.getElementById('coin'),
    coinCount: document.getElementById('coinCountElement'),
    energiaFill: document.getElementById('energiaFill'),
    levelFill: document.getElementById('levelFill'),
    levelDisplay: document.getElementById('levelElement'),
    energiaText: document.getElementById('energiaText'),
    levelText: document.getElementById('levelText'),
    rechargeButton: document.getElementById('rechargeButton'),
    lotteryButton: document.getElementById('lotteryButton'),
    gameContainer: document.querySelector('.game-frame'),
    usernameElement: document.getElementById('usernameElement'),
    maxEnergiaElement: document.getElementById('maxEnergiaElement'),
};

// Utility Functions
function logWithTimestamp(message, level = 'info') {
    const timestamp = new Date().toISOString();
    console[level](`[${timestamp}] ${message}`);
}

function trackPerformance(functionName, startTime) {
    const duration = performance.now() - startTime;
    logWithTimestamp(`${functionName} executed in ${duration.toFixed(2)}ms`, 'debug');
}

function sanitizeInput(input) {
    return DOMPurify.sanitize(input);
}

// Storage Functions
const storage = {
    set: (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            sessionStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            logWithTimestamp(`Error setting storage item: ${e}`, 'error');
        }
    },
    get: (key) => {
        const value = sessionStorage.getItem(key) || localStorage.getItem(key);
        try {
            return value ? JSON.parse(value) : null;
        } catch (e) {
            logWithTimestamp(`Error parsing storage item: ${e}`, 'error');
            return null;
        }
    },
    remove: (key) => {
        try {
            localStorage.removeItem(key);
            sessionStorage.removeItem(key);
        } catch (e) {
            logWithTimestamp(`Error removing storage item: ${e}`, 'error');
        }
    }
};

// API Functions
async function secureFetch(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    const { sessionId, token } = getGameState();

    if (sessionId) {
        headers['X-Session-ID'] = sessionId;
    }

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    try {
        const response = await fetch(url, {
            ...options,
            headers: headers
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response;
    } catch (error) {
        logWithTimestamp(`Error in secureFetch: ${error.message}`, 'error');
        throw error;
    }
}

async function getSessionIdAndToken() {
    const coinElement = document.getElementById('coin');
    const sessionId = coinElement.dataset.sessionId;
    const token = coinElement.dataset.token;

    if (sessionId && token) {
        storage.set('sessionId', sessionId);
        storage.set('token', token);
        updateGameState({ sessionId, token });
        return { sessionId, token };
    } else {
        logWithTimestamp('Session ID or token not found in coin element', 'warn');
        return null;
    }
}

async function loadUserData() {
    for (let i = 0; i < config.maxRetries; i++) {
        try {
            const response = await secureFetch(`${config.gameUrl}/api/user/stats`, {
                method: 'GET'
            });

            const data = await response.json();
            updateGameState({ userProgress: data });
            updateUI(data);
            return true;
        } catch (error) {
            logWithTimestamp(`Error in loadUserData (attempt ${i + 1}): ${error.message}`, 'error');
            if (i === config.maxRetries - 1) {
                showNotification('Error', 'Failed to load user data. Please try again later.', 'error');
                return false;
            }
            await new Promise(resolve => setTimeout(resolve, config.retryDelay));
        }
    }
}


// UI Functions
function updateUI(userData) {
    if (!userData) {
        logWithTimestamp('User progress data is not available', 'warn');
        return;
    }

    const { energia, max_energia, level, experience, coins } = userData;

    elements.energiaFill.style.width = `${(energia / max_energia) * 100}%`;
    elements.energiaText.textContent = `${energia} / ${max_energia}`;
    elements.levelFill.style.width = `${(experience / 100) * 100}%`;
    elements.levelText.textContent = `Level ${level}`;
    elements.coinCount.textContent = coins;
    elements.levelDisplay.textContent = level;

    logWithTimestamp('UI updated successfully');
}

function showNotification(title, message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `<strong>${sanitizeInput(title)}</strong><p>${sanitizeInput(message)}</p>`;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, config.notificationDuration);
}

function showModal(title, message, buttons = []) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    let buttonHtml = '';
    if (buttons.length > 0) {
        buttonHtml = '<div class="modal-buttons">' + 
            buttons.map(button => `<button class="${button.class}">${button.text}</button>`).join('') +
            '</div>';
    } else {
        buttonHtml = '<button class="close-button">Zamknij</button>';
    }
    
    modal.innerHTML = `
        <div class="modal-content">
            <h2>${sanitizeInput(title)}</h2>
            <p>${sanitizeInput(message)}</p>
            ${buttonHtml}
        </div>
    `;

    document.body.appendChild(modal);

    const closeModal = () => modal.remove();

    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            closeModal();
        }
    });

    const closeButton = modal.querySelector('.close-button');
    if (closeButton) {
        closeButton.addEventListener('click', closeModal);
    }

    buttons.forEach(button => {
        const buttonElement = modal.querySelector(`.${button.class}`);
        if (buttonElement) {
            buttonElement.addEventListener('click', () => {
                button.onClick();
                closeModal();
            });
        }
    });
}

function showModal2(title, message) {
    const modal = document.createElement('div');
    modal.className = 'modal2';
    modal.innerHTML = `
        <div class="modal2-content">
            <h2>${sanitizeInput(title)}</h2>
            <p>${sanitizeInput(message)}</p>
            <div class="modal2-buttons">
                <button class="close-button">Zamknij</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    const closeButton = modal.querySelector('.close-button');

    closeButton.addEventListener('click', () => {
        document.body.removeChild(modal);
    });

    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            document.body.removeChild(modal);
        }
    });
}



function displayError(message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    document.body.appendChild(errorElement);
}

// Tab Functions
function switchTab(event) {
    const tab = event.target.closest('.tab');
    if (!tab) return;

    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

    tab.classList.add('active');

    const tabName = tab.getAttribute('data-tab');
    document.getElementById(tabName).classList.add('active');
}

// App Initialization
async function initializeApp() {
    try {
        const sessionData = await getSessionIdAndToken();
        if (!sessionData) {
            throw new Error('Invalid session or token');
        }

        const userDataLoaded = await loadUserData();
        if (!userDataLoaded) {
            throw new Error('Failed to load user data');
        }

        if (tg && tg.__telegram__initParams) {
            tg.__telegram__initParams = {
                ...tg.__telegram__initParams,
                session_id: sessionData.sessionId,
                token: sessionData.token
            };
        }

        document.querySelectorAll('.tab').forEach(tab => tab.addEventListener('click', switchTab));
        logWithTimestamp('App initialized successfully');
    } catch (error) {
        logWithTimestamp(`Error initializing app: ${error.message}`, 'error');
        displayError(`Cannot initialize app: ${error.message}`);
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', async () => {
    const startTime = performance.now();

    try {
        await initializeApp();
    } catch (error) {
        logWithTimestamp(`Error in DOMContentLoaded: ${error.message}`, 'error');
        displayError(`Error loading app: ${error.message}`);
    } finally {
        trackPerformance('DOMContentLoaded', startTime);
    }
});

// Telegram WebApp Setup
if (tg) {
    tg.expand();
    tg.ready();
}