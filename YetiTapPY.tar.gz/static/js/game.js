// Game Functions
const BASE_EXP = 100; // Base experience required for level 2
const GROWTH_RATE = 1.5; // Exponential growth rate
const PERCENTAGE_INCREASE = 0.1; // 10% increase per level

// Calculate experience required for next level
function calculateExpForNextLevel(level) {
    const exponentialGrowth = Math.floor(BASE_EXP * Math.pow(GROWTH_RATE, level - 1));
    const percentageIncrease = Math.floor(BASE_EXP * (level - 1) * PERCENTAGE_INCREASE);
    return exponentialGrowth + percentageIncrease;
}


// Check for level up and handle multiple level ups

function checkLevelUp() {
    const { userProgress } = getGameState();
    let expForNextLevel = calculateExpForNextLevel(userProgress.level);
    let leveledUp = false;

    while (userProgress.experience >= expForNextLevel) {
        userProgress.level++;
        userProgress.experience -= expForNextLevel;
        userProgress.max_energia += 5;
        userProgress.energia = userProgress.max_energia;
        leveledUp = true;
        expForNextLevel = calculateExpForNextLevel(userProgress.level);
    }

    if (leveledUp) {
        updateGameState({ userProgress });
        showModal2('Gratulacje!', `Osiągnąłeś poziom ${userProgress.level}! Twoja energia została odnowiona.`);
    }

    // Update experience bar
    updateExperienceBar(userProgress.experience, expForNextLevel);
}

// Update experience bar in UI
function updateExperienceBar(currentExp, expForNextLevel) {
    const levelFill = document.getElementById('levelFill');
    const levelText = document.getElementById('levelText');
    const experienceElement = document.getElementById('experienceElement');

    const percentage = (currentExp / expForNextLevel) * 100;
    levelFill.style.width = `${percentage}%`;

    // Wyświetlanie ile brakuje do następnego poziomu
    const expToNextLevel = expForNextLevel - currentExp;
    levelText.textContent = `${currentExp} / ${expForNextLevel} (Brakuje ${expToNextLevel})`;
    experienceElement.textContent = currentExp;
}

// Inicjalizacja kliknięcia na monetę
function initializeCoinClicking() {
    const coin = document.getElementById('coin');
    let isClickingAllowed = true;

    coin.addEventListener('click', async () => {
        if (!isClickingAllowed) return; // Blokada wielokrotnych kliknięć

        const { userProgress } = getGameState();
        if (!userProgress) {
            logWithTimestamp('User progress not initialized', 'error');
            return;
        }

        if (userProgress.energia <= 0) {
            showModal2('Brak energii', 'Nie masz wystarczającej ilości energii. Poczekaj na regenerację lub użyj przedmiotu regenerującego.');
            return;
        }

        const actualMultiplier = 1;

        const updatedProgress = {
            ...userProgress,
            coins: userProgress.coins + actualMultiplier,
            experience: userProgress.experience + actualMultiplier,
            energia: Math.max(userProgress.energia - 1, 0)
        };

        updateGameState({ userProgress: updatedProgress });
        checkLevelUp();
        updateUI(updatedProgress);
        createSnowballEffect(coin, actualMultiplier);

        logWithTimestamp('Coin clicked');
        await updateUserData();

        // Zablokuj kliknięcie na krótki czas
        isClickingAllowed = false;
        setTimeout(() => {
            isClickingAllowed = true;
        }, 500); // Czas blokady w milisekundach
    });
}

function createSnowballEffect(coin, multiplier) {
    const gameArea = document.getElementById('game');
    const coinRect = coin.getBoundingClientRect();

    const snowball = document.createElement('div');
    snowball.classList.add('snowballEffect');
    snowball.textContent = `+${multiplier}`;

    const offsetX = Math.random() * coinRect.width * 0.8;
    const offsetY = Math.random() * coinRect.height * 0.8;

    snowball.style.left = `${coinRect.left + offsetX}px`;
    snowball.style.top = `${coinRect.top + offsetY}px`;

    gameArea.appendChild(snowball);

    const deviationX = (Math.random() - 0.5) * 10;
    const deviationY = (Math.random() - 0.5) * 10;

    snowball.style.transform = `translate(${deviationX}px, ${deviationY}px)`;

    setTimeout(() => {
        snowball.remove();
    }, 600);
}
async function updateUserData() {
  try {
    const userProgress = getGameState().userProgress;
    const response = await fetch('/api/user/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userProgress),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    return data; // Return the response data if needed
  } catch (error) {
    console.error('Error updating user data:', error);
    throw error; // Re-throw the error for further handling
  }
}
// Zastąp istniejącą funkcję regenerateEnergy tą nową implementacją
function regenerateEnergy() {
    setInterval(async () => {
        const { userProgress } = getGameState();
        if (userProgress && userProgress.energia < userProgress.max_energia) {
            const updatedProgress = {
                ...userProgress,
                energia: Math.min(userProgress.energia + 1, userProgress.max_energia)
            };
            updateGameState({ userProgress: updatedProgress });
            updateUI(updatedProgress);

            // Synchronizuj z serwerem
            try {
                await updateUserData();
                logWithTimestamp('Energy regenerated and synced with server');
            } catch (error) {
                logWithTimestamp(`Error syncing energy regeneration: ${error.message}`, 'error');
            }
        }
    }, config.energyRegenerationInterval);
}

// Dodaj tę funkcję do sprawdzania i resetowania interwału regeneracji
function checkAndResetEnergyRegeneration() {
    if (window.energyRegenerationInterval) {
        clearInterval(window.energyRegenerationInterval);
    }
    window.energyRegenerationInterval = setInterval(regenerateEnergy, config.energyRegenerationInterval);
}

function updateGameState(newState) {
    localStorage.setItem('userProgress', JSON.stringify(newState.userProgress));
}
// Wywołaj funkcje po załadowaniu strony
document.addEventListener('DOMContentLoaded', () => {
    initializeCoinClicking();
    checkAndResetEnergyRegeneration(); // Uruchom regenerację energii
    // ... (inne inicjalizacje, np. setupTabs() )
});