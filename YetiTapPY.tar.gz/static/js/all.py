// Configuration
const config = {
    gameUrl: window.location.origin,
    tokenRefreshInterval: 60000,
    tokenRefreshThreshold: 300000,
    notificationDuration: 3000,
    maxRetries: 3,
    retryDelay: 1000,
    energyRegenerationInterval: 5000,
    BASE_EXP: 100,
    GROWTH_RATE: 1.5,
    PERCENTAGE_INCREASE: 0.1
};

// Game State Management
const gameState = {
    sessionId: null,
    token: null,
    userProgress: null
};

function updateGameState(newState) {
    Object.assign(gameState, newState);
    localStorage.setItem('userProgress', JSON.stringify(newState.userProgress));
}

function getGameState() {
    return {
        ...gameState,
        userProgress: JSON.parse(localStorage.getItem('userProgress')) || {
            level: 1,
            experience: 0,
            max_energia: 100,
            energia: 100,
            coins: 0
        }
    };
}

// Utility Functions
function logWithTimestamp(message, level = 'info') {
    const timestamp = new Date().toISOString();
    console[level](`[${timestamp}] ${message}`);
}

function sanitizeInput(input) {
    return DOMPurify.sanitize(input);
}

// Game Functions
function calculateExpForNextLevel(level) {
    const exponentialGrowth = Math.floor(config.BASE_EXP * Math.pow(config.GROWTH_RATE, level - 1));
    const percentageIncrease = Math.floor(config.BASE_EXP * (level - 1) * config.PERCENTAGE_INCREASE);
    return exponentialGrowth + percentageIncrease;
}

function checkLevelUp() {
    const { userProgress } = getGameState();
    let expForNextLevel = calculateExpForNextLevel(userProgress.level);
    let leveledUp = false;

    while (userProgress.experience >= expForNextLevel) {
        userProgress.level++;
        userProgress.experience -= expForNextLevel;
        userProgress.max_energia += 5;
        userProgress.energia = userProgress.max_energia;
        leveledUp = true;
        expForNextLevel = calculateExpForNextLevel(userProgress.level);
    }

    if (leveledUp) {
        updateGameState({ userProgress });
        showModal2('Gratulacje!', `Osiągnąłeś poziom ${userProgress.level}! Twoja energia została odnowiona.`);
    }

    updateExperienceBar(userProgress.experience, expForNextLevel);
}

function updateExperienceBar(currentExp, expForNextLevel) {
    const levelFill = document.getElementById('levelFill');
    const levelText = document.getElementById('levelText');
    const experienceElement = document.getElementById('experienceElement');

    const percentage = (currentExp / expForNextLevel) * 100;
    levelFill.style.width = `${percentage}%`;

    const expToNextLevel = expForNextLevel - currentExp;
    levelText.textContent = `${currentExp} / ${expForNextLevel} (Brakuje ${expToNextLevel})`;
    experienceElement.textContent = currentExp;
}

function initializeCoinClicking() {
    const coin = document.getElementById('coin');
    let isClickingAllowed = true;

    coin.addEventListener('click', async () => {
        if (!isClickingAllowed) return;

        const { userProgress } = getGameState();
        if (!userProgress) {
            logWithTimestamp('User progress not initialized', 'error');
            return;
        }

        if (userProgress.energia <= 0) {
            showModal2('Brak energii', 'Nie masz wystarczającej ilości energii. Poczekaj na regenerację lub użyj przedmiotu regenerującego.');
            return;
        }

        const actualMultiplier = 1;

        const updatedProgress = {
            ...userProgress,
            coins: userProgress.coins + actualMultiplier,
            experience: userProgress.experience + actualMultiplier,
            energia: Math.max(userProgress.energia - 1, 0)
        };

        updateGameState({ userProgress: updatedProgress });
        checkLevelUp();
        updateUI(updatedProgress);
        createSnowballEffect(coin, actualMultiplier);

        logWithTimestamp('Coin clicked');
        await updateUserData();

        isClickingAllowed = false;
        setTimeout(() => {
            isClickingAllowed = true;
        }, 500);
    });
}

function createSnowballEffect(coin, multiplier) {
    const gameArea = document.getElementById('game');
    const coinRect = coin.getBoundingClientRect();

    const snowball = document.createElement('div');
    snowball.classList.add('snowballEffect');
    snowball.textContent = `+${multiplier}`;

    const offsetX = Math.random() * coinRect.width * 0.8;
    const offsetY = Math.random() * coinRect.height * 0.8;

    snowball.style.left = `${coinRect.left + offsetX}px`;
    snowball.style.top = `${coinRect.top + offsetY}px`;

    gameArea.appendChild(snowball);

    const deviationX = (Math.random() - 0.5) * 30;
    const deviationY = (Math.random() - 0.5) * 30;

    snowball.animate([
        { transform: `translate(${deviationX}px, ${deviationY}px) scale(0.5)`, opacity: 1 },
        { transform: `translate(${deviationX * 2}px, ${deviationY * 2 - 100}px) scale(1.2)`, opacity: 1, offset: 0.5 },
        { transform: `translate(${deviationX * 3}px, ${deviationY * 3 - 200}px) scale(0.8)`, opacity: 0 }
    ], {
        duration: 1000,
        easing: 'ease-out'
    });

    setTimeout(() => {
        snowball.remove();
    }, 1000);
}

function regenerateEnergy() {
    setInterval(async () => {
        const { userProgress } = getGameState();
        if (userProgress && userProgress.energia < userProgress.max_energia) {
            const updatedProgress = {
                ...userProgress,
                energia: Math.min(userProgress.energia + 1, userProgress.max_energia)
            };
            updateGameState({ userProgress: updatedProgress });
            updateUI(updatedProgress);

            try {
                await updateUserData();
                logWithTimestamp('Energy regenerated and synced with server');
            } catch (error) {
                logWithTimestamp(`Error syncing energy regeneration: ${error.message}`, 'error');
            }
        }
    }, config.energyRegenerationInterval);
}

// UI Functions
function updateUI(userData) {
    if (!userData) {
        logWithTimestamp('User progress data is not available', 'warn');
        return;
    }

    const { energia, max_energia, level, experience, coins } = userData;

    const elements = {
        energiaFill: document.getElementById('energiaFill'),
        energiaText: document.getElementById('energiaText'),
        levelFill: document.getElementById('levelFill'),
        levelText: document.getElementById('levelText'),
        coinCount: document.getElementById('coinCountElement'),
        levelDisplay: document.getElementById('levelElement')
    };

    if (elements.energiaFill) elements.energiaFill.style.width = `${(energia / max_energia) * 100}%`;
    if (elements.energiaText) elements.energiaText.textContent = `${energia} / ${max_energia}`;
    if (elements.levelFill) elements.levelFill.style.width = `${(experience / calculateExpForNextLevel(level)) * 100}%`;
    if (elements.levelText) elements.levelText.textContent = `Level ${level}`;
    if (elements.coinCount) elements.coinCount.textContent = coins;
    if (elements.levelDisplay) elements.levelDisplay.textContent = level;

    logWithTimestamp('UI updated successfully');
}

function showModal2(title, message) {
    const modal = document.createElement('div');
    modal.className = 'modal2';
    modal.innerHTML = `
        <div class="modal2-content">
            <h2>${sanitizeInput(title)}</h2>
            <p>${sanitizeInput(message)}</p>
            <div class="modal2-buttons">
                <button class="close-button">Zamknij</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    const closeButton = modal.querySelector('.close-button');

    closeButton.addEventListener('click', () => {
        document.body.removeChild(modal);
    });

    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

// API Functions
async function secureFetch(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    const { sessionId, token } = getGameState();

    if (sessionId) {
        headers['X-Session-ID'] = sessionId;
    }

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    try {
        const response = await fetch(url, {
            ...options,
            headers: headers
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response;
    } catch (error) {
        logWithTimestamp(`Error in secureFetch: ${error.message}`, 'error');
        throw error;
    }
}

async function getSessionIdAndToken() {
    const coinElement = document.getElementById('coin');
    const sessionId = coinElement.dataset.sessionId;
    const token = coinElement.dataset.token;

    if (sessionId && token) {
        updateGameState({ sessionId, token });
        return { sessionId, token };
    } else {
        logWithTimestamp('Session ID or token not found in coin element', 'warn');
        return null;
    }
}

async function loadUserData() {
    for (let i = 0; i < config.maxRetries; i++) {
        try {
            const response = await secureFetch(`${config.gameUrl}/api/user/stats`, {
                method: 'GET'
            });

            const data = await response.json();
            updateGameState({ userProgress: data });
            updateUI(data);
            return true;
        } catch (error) {
            logWithTimestamp(`Error in loadUserData (attempt ${i + 1}): ${error.message}`, 'error');
            if (i === config.maxRetries - 1) {
                showModal2('Error', 'Failed to load user data. Please try again later.');
                return false;
            }
            await new Promise(resolve => setTimeout(resolve, config.retryDelay));
        }
    }
}

async function updateUserData() {
    const { sessionId, userProgress } = getGameState();
    try {
        await secureFetch(`${config.gameUrl}/api/user/update`, {
            method: 'POST',
            body: JSON.stringify({...userProgress, sessionId }),
        });
        logWithTimestamp('User data updated on server');
    } catch (error) {
        logWithTimestamp(`Error in updateUserData: ${error.message}`, 'error');
    }
}

// App Initialization
async function initializeApp() {
    try {
        const sessionData = await getSessionIdAndToken();
        if (!sessionData) {
            throw new Error('Invalid session or token');
        }

        const userDataLoaded = await loadUserData();
        if (!userDataLoaded) {
            throw new Error('Failed to load user data');
        }

        initializeCoinClicking();
        regenerateEnergy();

        document.querySelectorAll('.tab').forEach(tab => tab.addEventListener('click', switchTab));
        logWithTimestamp('App initialized successfully');
    } catch (error) {
        logWithTimestamp(`Error initializing app: ${error.message}`, 'error');
        showModal2('Error', `Cannot initialize app: ${error.message}`);
    }
}

// Tab Functions
function switchTab(event) {
    const tab = event.target.closest('.tab');
    if (!tab) return;

    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

    tab.classList.add('active');

    const tabName = tab.getAttribute('data-tab');
    document.getElementById(tabName).classList.add('active');
}

// Event Listeners
document.addEventListener('DOMContentLoaded', initializeApp);

// Telegram WebApp Setup
const tg = window.Telegram.WebApp;
if (tg) {
    tg.expand();
    tg.ready();
}

// Expose necessary functions
window.initializeApp = initializeApp;
window.updateUI = updateUI;
window.showModal2 = showModal2;